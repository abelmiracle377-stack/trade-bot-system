from .signal import SignalGenerator
