from .predictor import SignalPredictor
