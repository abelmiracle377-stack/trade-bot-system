"""Machine learning models for return / direction prediction."""

from typing import Any, Dict, List, Optional, Tuple
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, roc_auc_score
from sklearn.preprocessing import StandardScaler
import xgboost as xgb
import joblib
from pathlib import Path
from loguru import logger


class SignalPredictor:
    """
    Predict probability that next N-day return is positive.
    Supports XGBoost, RandomForest, LogisticRegression.
    """

    def __init__(
        self,
        model_type: str = "xgboost",
        target_horizon: int = 5,
        model_params: Optional[Dict[str, Any]] = None,
        random_state: int = 42,
    ):
        self.model_type = model_type.lower()
        self.target_horizon = target_horizon
        self.model_params = model_params or {}
        self.random_state = random_state
        self.model = None
        self.scaler = StandardScaler()
        self.feature_names: List[str] = []
        self.is_fitted = False

    def _create_target(self, df: pd.DataFrame) -> pd.Series:
        """Binary target: 1 if forward return > 0 over horizon."""
        future_ret = df["Close"].pct_change(self.target_horizon).shift(-self.target_horizon)
        return (future_ret > 0).astype(int)

    def _build_model(self):
        if self.model_type == "xgboost":
            params = {
                "n_estimators": 300,
                "max_depth": 6,
                "learning_rate": 0.05,
                "subsample": 0.8,
                "colsample_bytree": 0.8,
                "reg_alpha": 0.1,
                "reg_lambda": 1.0,
                "objective": "binary:logistic",
                "eval_metric": "logloss",
                "random_state": self.random_state,
                "n_jobs": -1,
            }
            params.update(self.model_params)
            return xgb.XGBClassifier(**params)

        elif self.model_type == "random_forest":
            params = {
                "n_estimators": 200,
                "max_depth": 10,
                "min_samples_leaf": 20,
                "random_state": self.random_state,
                "n_jobs": -1,
                "class_weight": "balanced",
            }
            params.update(self.model_params)
            return RandomForestClassifier(**params)

        elif self.model_type == "logistic":
            return LogisticRegression(
                max_iter=1000,
                random_state=self.random_state,
                class_weight="balanced",
            )
        else:
            raise ValueError(f"Unknown model_type: {self.model_type}")

    def prepare_data(
        self,
        df: pd.DataFrame,
        feature_cols: List[str],
    ) -> Tuple[pd.DataFrame, pd.Series]:
        """Create features + target, drop NaNs."""
        data = df.copy()
        data["target"] = self._create_target(data)
        data = data.dropna(subset=feature_cols + ["target"])
        X = data[feature_cols]
        y = data["target"]
        return X, y

    def fit(
        self,
        df: pd.DataFrame,
        feature_cols: List[str],
        test_size: float = 0.2,
    ) -> Dict[str, float]:
        """Train model and return evaluation metrics."""
        X, y = self.prepare_data(df, feature_cols)
        self.feature_names = feature_cols

        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, shuffle=False, random_state=self.random_state
        )

        # Scale (important for logistic; harmless for tree models)
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)

        self.model = self._build_model()
        self.model.fit(X_train_scaled, y_train)
        self.is_fitted = True

        # Evaluation
        proba = self.model.predict_proba(X_test_scaled)[:, 1]
        preds = (proba >= 0.5).astype(int)

        metrics = {
            "accuracy": accuracy_score(y_test, preds),
            "roc_auc": roc_auc_score(y_test, proba) if len(np.unique(y_test)) > 1 else 0.0,
            "n_train": len(X_train),
            "n_test": len(X_test),
            "positive_rate_train": y_train.mean(),
            "positive_rate_test": y_test.mean(),
        }

        logger.info(
            f"Model trained ({self.model_type}) | "
            f"Acc={metrics['accuracy']:.3f} | AUC={metrics['roc_auc']:.3f} | "
            f"Train={metrics['n_train']} Test={metrics['n_test']}"
        )
        logger.debug("\n" + classification_report(y_test, preds, zero_division=0))
        return metrics

    def predict_proba(self, df: pd.DataFrame) -> pd.Series:
        """Return probability of positive forward return."""
        if not self.is_fitted:
            raise RuntimeError("Model not fitted. Call fit() first.")

        X = df[self.feature_names].copy()
        # Handle missing values at inference (forward-fill then zero)
        X = X.ffill().fillna(0)
        X_scaled = self.scaler.transform(X)
        proba = self.model.predict_proba(X_scaled)[:, 1]
        return pd.Series(proba, index=df.index, name="signal_proba")

    def save(self, path: str | Path):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(
            {
                "model": self.model,
                "scaler": self.scaler,
                "feature_names": self.feature_names,
                "model_type": self.model_type,
                "target_horizon": self.target_horizon,
            },
            path,
        )
        logger.info(f"Model saved → {path}")

    def load(self, path: str | Path):
        obj = joblib.load(path)
        self.model = obj["model"]
        self.scaler = obj["scaler"]
        self.feature_names = obj["feature_names"]
        self.model_type = obj["model_type"]
        self.target_horizon = obj["target_horizon"]
        self.is_fitted = True
        logger.info(f"Model loaded ← {path}")
